# JIBRO · 주거지원 준비노트

주거지원 공고를 확인하고 공고별 조건·서류 준비 상태를 기록하는 모바일 웹 앱입니다.

## 구성

- `src/`, `public/`: React + Vite 프론트엔드
- `backend/`: Java 17 + Spring Boot MVC 서버
- `src/lhNotices.js`: 미리 수집한 LH 공고 목록. 실시간 데이터가 아닙니다.

## 프론트엔드 실행

Node.js 22.12 이상과 npm을 설치한 뒤 실행합니다.

```sh
npm ci
npm run dev
```

개발 주소는 http://localhost:5173 입니다. 배포 파일은 `npm run build`로 생성합니다.

## 서버 실행 및 연결

Java 17과 Gradle 8.x가 필요합니다. Gradle Wrapper는 아직 포함하지 않았습니다.

```sh
cd backend
gradle bootRun
```

프로젝트 루트에 `.env.local`을 만들고 다음 값을 설정한 뒤 프론트엔드를 다시 실행합니다.

```dotenv
VITE_API_BASE=http://localhost:8080
```

설정하지 않으면 준비 기록은 해당 브라우저에 저장됩니다. 다른 기기와 동기화되지 않습니다.

## 현재 구현 상태와 제한

- 상세 공고와 현재 준비 공고를 구분하고, 시작 버튼으로 준비 대상을 변경합니다.
- 서버 미연결 상태의 URL 가져오기는 링크만 저장합니다.
- Spring 공고 수집·가져오기 코드는 구현 초안이며 운영 배포 및 실행 검증이 완료되지 않았습니다. 페이지 수집 범위, 신청 기간 추출, 첨부파일 분석은 추가 검증이 필요합니다.
- 서버 기록 저장은 기기 식별자별 JSON 파일 방식입니다. 로그인 기반 사용자 인증·권한 확인·데이터베이스 저장을 구현한 상태가 아니므로 외부 운영 서버로 바로 공개하지 마세요.
- 서류 목록은 준비용 참고 항목입니다. 실제 공고의 필수 서류를 분석해 확정한 목록이 아닙니다.
- 공고 날짜·신청 자격·제출 서류는 공식 공고를 최종 기준으로 확인해야 합니다.

## 협업

수정 방법은 [CONTRIBUTING.md](CONTRIBUTING.md)를 참고하세요.
프로젝트 구조·수정 원칙·확인 항목은 [agent.md](agent.md)에 정리되어 있습니다. AI 도구용 진입점은 [AGENTS.md](AGENTS.md)입니다.

### 빠른 협업 시작

```sh
git clone https://github.com/cho-mi-kim/jibro-housing-prep.git
cd jibro-housing-prep
npm ci
npm run dev
```

작업은 `feature/작업이름` 브랜치에서 진행하고 `main`으로 Pull Request를 보내주세요.
Pull Request가 올라오면 GitHub Actions가 프론트엔드와 백엔드를 빌드합니다.
작업 전에는 [CONTRIBUTING.md](CONTRIBUTING.md)의 절차와 [agent.md](agent.md)의 데이터·접근성 기준을 확인합니다.

### 협업 저장소 설정 체크리스트

저장소 소유자는 GitHub **Settings → Collaborators**에서 작업자를 초대하고, **Settings → Rules → Rulesets** 또는 브랜치 보호 규칙에서 다음을 설정하는 것이 좋습니다.

- `main` 직접 Push 금지
- Pull Request를 통한 병합만 허용
- `JIBRO CI / Frontend build`, `JIBRO CI / Backend build` 통과 필수
- 최소 1명 리뷰 승인 필수
- 새 커밋이 올라오면 이전 승인 무효화
- Code Owner 리뷰가 필요한 경우 `CODEOWNERS` 적용

이 저장소에는 협업 파일과 자동 빌드 설정을 넣었지만, GitHub의 Collaborator 초대와 `main` 보호 규칙은 저장소 Settings에서 직접 켜야 합니다.
